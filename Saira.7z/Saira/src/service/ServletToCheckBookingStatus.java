package service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;


/**
 * Servlet implementation class ServletForBookingStatus
 */
public class ServletToCheckBookingStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletToCheckBookingStatus() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		RequestDispatcher rd=request.getRequestDispatcher("statusCheck.jsp");
		try{
		Connection con=connections.ConnectionToDB.getConnection();
		Statement st=con.createStatement();
		String x= request.getParameter("bookingId");
		
		ResultSet rs=st.executeQuery("Select * from metroCabs_status where bookingID='"+x+"'");
		
		while(rs.next())
		{
			out.println("Your Status:"+rs.getString("Status") +"for booking Id"+rs.getString("bookingId"));
		}
		rd.include(request, response);
		}
		catch(Exception e)
		
		{
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		RequestDispatcher rd=request.getRequestDispatcher("statusCheck.jsp");
		try{
		Connection con=connections.ConnectionToDB.getConnection();
		Statement st=con.createStatement();
		String x= request.getParameter("bookingId");
	    
		ResultSet rs=st.executeQuery("Select * from metroCabs_status where bookingID='"+x+"'");
		
		while(rs.next())
		{
			
			out.println("Your Status:"+rs.getString("Status") +"for booking Id"+rs.getString("bookingId"));
		}
		rd.include(request, response);
		}
		catch(Exception e)
		
		{
			
		}
	}

}
