package service;

import java.sql.SQLException;

import  beans.BeansForMetroCabs;
import daoImplementation.BookingDaoImplementation;
import dao.BookingDao;

public class BookingService {

	public int bookServiceFx(BeansForMetroCabs booking1) throws ClassNotFoundException, SQLException{
		BookingDao bookDao = new BookingDaoImplementation();
        return bookDao.bookUser(booking1);
    }
}