package service;

import java.sql.SQLException;

import beans.BeanForStatusUpdate;
import beans.BeanForDriverDetails;

import dao.StatusUpdateDao;
import daoImplementation.StatusUpdateImplementation;





public class StatusUpdateService implements StatusUpdateDao {

	public int updateStatusDao(BeanForStatusUpdate booking1 ,BeanForDriverDetails driver1) throws ClassNotFoundException, SQLException{
		StatusUpdateDao statusUpdate = new StatusUpdateImplementation();
        return statusUpdate.updateStatusDao(booking1,driver1);	
	
	
}

	
}