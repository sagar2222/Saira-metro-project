package service;

import java.sql.SQLException;

import  beans.BeanForAddingFeedBack;
import daoImplementation.AddingFeedbackDaoImplementation;
import dao.AddingFeedbackDao;


public class AddingFeedbackService {

	public int addFeedbackService(BeanForAddingFeedBack booking1) throws ClassNotFoundException, SQLException{
		AddingFeedbackDao addfeedbackDao = new AddingFeedbackDaoImplementation();
        return addfeedbackDao.addFeedback(booking1);
    }
}