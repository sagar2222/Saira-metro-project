package service;

import java.sql.SQLException;

import dao.AdminLoginDao;
import daoImplementation.AdminLoginDaoImplementation;
import beans.AdminLogin;

public class AdminLoginService {

		public String validateUser(AdminLogin login) throws ClassNotFoundException, SQLException
		{
	        AdminLoginDao adminloginDao = new AdminLoginDaoImplementation();
	        return adminloginDao.validateUser(login);

    			}


	}

	
	
	



