package dao;
import java.sql.SQLException;

import  beans.BeanForAddingFeedBack;



public interface AddingFeedbackDao {

	public abstract int addFeedback(BeanForAddingFeedBack bookRegister ) throws ClassNotFoundException, SQLException;
	
}




