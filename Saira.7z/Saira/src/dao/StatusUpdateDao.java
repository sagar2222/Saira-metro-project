package dao;

import java.sql.SQLException;

import beans.BeanForStatusUpdate;
import beans.BeanForDriverDetails;




public interface StatusUpdateDao {
	
	public abstract int updateStatusDao(BeanForStatusUpdate bookRegister,BeanForDriverDetails driver1) throws ClassNotFoundException, SQLException;
	
}
