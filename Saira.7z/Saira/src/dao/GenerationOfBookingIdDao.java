package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import beans.BeanForBookingId;
import dao.GenerationOfBookingIdDao;
import connections.ConnectionToDB;





public interface GenerationOfBookingIdDao {

	
	public abstract int generateBookingIdDao(BeanForBookingId booking1 ) throws ClassNotFoundException, SQLException;
	
	
	
}
