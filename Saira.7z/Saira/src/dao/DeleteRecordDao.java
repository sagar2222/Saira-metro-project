package dao;

import java.sql.SQLException;

import beans.BeanForDeletingRecord;

public interface DeleteRecordDao {

				public abstract int deleteRecordDao(BeanForDeletingRecord bookRegister ) throws ClassNotFoundException, SQLException;
		
	}
