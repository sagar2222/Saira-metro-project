package dao;

import java.sql.SQLException;

import beans.AdminLogin;

public interface AdminLoginDao {

	public abstract String validateUser(AdminLogin login ) throws ClassNotFoundException, SQLException;

}
