package dao;
import java.sql.SQLException;

import  beans.BeansForMetroCabs;

public interface BookingDao {

	public abstract int bookUser(BeansForMetroCabs bookRegister ) throws ClassNotFoundException, SQLException;
	
}




