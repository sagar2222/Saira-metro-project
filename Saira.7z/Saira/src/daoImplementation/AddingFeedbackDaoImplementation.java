package daoImplementation;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/*import org.apache.catalina.tribes.group.Response;*/

import beans.BeanForAddingFeedBack;
import dao.AddingFeedbackDao;
import connections.ConnectionToDB;



public class AddingFeedbackDaoImplementation implements AddingFeedbackDao {


	public int addFeedback(BeanForAddingFeedBack booking1) throws ClassNotFoundException, SQLException{

		
		Connection con = ConnectionToDB.getConnection();
		//Step 3: Creating empty statement object
		Statement st=con.createStatement();
		
		//Step 4: Creating SQL query , executing and processing
		System.out.println(booking1.getBookinId());
		//String feedBackQuery="INSERT INTO METROCABS VALUES('&FIRSTNAME','&LASTNAME','&TIMEOFBOOKING','&CITY','&PICKUPPLACE','&LANDMARK','&DESTINATION','&TYPEOFVEHICLES','&SERVICETYPE','&EMAIL','&NUMBEROFPERSONS','&IDNUMBER','&DATEOFTRAVEL','&CONTACTNUMBER' ,"  + "'"  +feedBack+ "'" + "," +"&BOOKINGID)";
		String feedBackQuery="UPDATE METROCABS SET FEEDBACK='" +booking1.getFeedBack()+ "' WHERE BOOKINGID='"+booking1.getBookinId() +"'";
		//Step 4.1 :Executing SQL Statement
		ResultSet rs= st.executeQuery(feedBackQuery);
		int i= st.executeUpdate(feedBackQuery);
		rs.close();
		return i;
	}

}
	