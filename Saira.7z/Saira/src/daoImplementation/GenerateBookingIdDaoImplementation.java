package daoImplementation;


import java.io.PrintWriter;
import java.sql.ResultSet;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/*import org.apache.catalina.tribes.group.Response;*/

import  beans.BeanForBookingId;
import dao.GenerationOfBookingIdDao;
import connections.ConnectionToDB;





public class GenerateBookingIdDaoImplementation implements GenerationOfBookingIdDao {

public int generateBookingIdDao(BeanForBookingId booking1) throws ClassNotFoundException, SQLException{
		
		
		Connection con = ConnectionToDB.getConnection();
        
		Statement st=con.createStatement();
		
		//Step 4: Creating SQL query , executing and processing
		String statusUpdateQuery= "UPDATE METROCABS SET BOOKINGID='"+booking1.getBookingId()+"' WHERE CONTACTNUMBER='"+booking1.getContactNumber()+"'";
		
		String statusUpdateQuery2= "INSERT INTO METROCABS_STATUS BOOKINGID VALUES('"+booking1.getBookingId()+"','"+null+"')";
		
		//Step 4.1 :Executing SQL Statement
		ResultSet rs= st.executeQuery(statusUpdateQuery);
		ResultSet rs2= st.executeQuery(statusUpdateQuery2);

		
		rs.close();
		rs2.close();

		int i= st.executeUpdate(statusUpdateQuery);
		return i;
	}



}	
		

	
	

