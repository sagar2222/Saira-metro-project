package beans;

public class BeanForViewingFeedback {

	private String bookingId;
	
	
	public BeanForViewingFeedback() {

	}
	
	public BeanForViewingFeedback(String bookingId) {

	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	
	
	
	
}
