package controllers;
import java.io.*;  
import java.sql.*;  

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;  
import javax.servlet.http.*; 

import service.AddingFeedbackService;
import service.GenerationOfBookingIdService;

import beans.BeanForBookingId;



public class GenerationOfBookingId extends HttpServlet {  
	
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response)  
			throws ServletException, IOException {  
//Set Response type
		response.setContentType("text/html");  
		PrintWriter out = response.getWriter();  

		
		
		
		BeanForBookingId booking1=new BeanForBookingId(); 
		
		
		

		
		
		
		
        //request.setAttribute(BeansForMetroCabs, BeansForMetroCabs);
		
		//AddingFeedbackService bookService= new AddingFeedbackService();

		GenerationOfBookingIdService newBookingIdService= new GenerationOfBookingIdService();
		
        try {
		int j = newBookingIdService.generateBookingId(booking1);
			 if(j>0){
				request.setAttribute("mesg", "Generate BookingId.");
				 RequestDispatcher rd=request.getRequestDispatcher("AdminUpdates.jsp");
			     rd.include(request, response); 
		        }
			 else{
				 request.setAttribute("mesg", "feedback registration failed");
			     RequestDispatcher rd=request.getRequestDispatcher("Home.html");
			     rd.include(request, response);   	 
				 
			 }
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
	}


}
