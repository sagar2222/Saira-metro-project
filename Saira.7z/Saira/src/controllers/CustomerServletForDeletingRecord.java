package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.StatusUpdateService;
import beans.BeanForDriverDetails;
import beans.BeanForStatusUpdate;

/**
 * Servlet implementation class CustomerServletForDeletingRecord
 */
public class CustomerServletForDeletingRecord extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerServletForDeletingRecord() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");  
		PrintWriter out = response.getWriter();  

		String bookingId = request.getParameter("bookingId");  
		String status = request.getParameter("status");
			
		BeanForStatusUpdate booking1 = new BeanForStatusUpdate();
		BeanForDriverDetails driver1=new BeanForDriverDetails();
		
		booking1.setBookingId(bookingId);
		booking1.setStatus(status);
        //request.setAttribute(BeansForMetroCabs, BeansForMetroCabs);
		

		StatusUpdateService UpdateStatusService= new StatusUpdateService();
		       
		try 
		{
		int j = UpdateStatusService.updateStatusDao(booking1,driver1);
		
			 if(j>0){
				 request.setAttribute("mesg", "Update Status.");
				 RequestDispatcher rd=request.getRequestDispatcher("StausOfBookings.jsp");
			     rd.include(request, response); 
		        }
			 else{
				 request.setAttribute("mesg", "Status Updation failed");
			     RequestDispatcher rd=request.getRequestDispatcher("Home.html");
			     rd.include(request, response);   	 
				 
			 }
		}
        catch (ClassNotFoundException | SQLException e)
        {
			e.printStackTrace();
		}
	}

}
