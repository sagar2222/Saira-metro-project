package controllers;
import java.io.*;  
import java.sql.*;  

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;  
import javax.servlet.http.*; 

import service.AddingFeedbackService;
import service.StatusUpdateService;

import beans.BeanForDriverDetails;
import beans.BeanForStatusUpdate;



public class AdminServletForUpdatingSataus extends HttpServlet {  
	
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response)  
			throws ServletException, IOException {  
//Set Response type
		response.setContentType("text/html");  
		PrintWriter out = response.getWriter();  

		String bookingId = request.getParameter("bookingId");  
		String status = request.getParameter("status");
	    
		//driver Data-request
		String DriverName=request.getParameter("DriverName");
		String EmployeeNumber=request.getParameter("EmployeeNumber");
		String CabNumber=request.getParameter("CabNumber");
		String CabColor=request.getParameter("CabColor");
		String DriverMobile=request.getParameter("DriverMobile");
		String EstimatedCost=request.getParameter("Cost");
		String pickupTime=request.getParameter("time");
		
		
		BeanForStatusUpdate booking1 = new BeanForStatusUpdate();
		BeanForDriverDetails driver1=new BeanForDriverDetails();
		
		booking1.setBookingId(bookingId);
		booking1.setStatus(status);
		
		driver1.setDriverName(DriverName);
		driver1.setdriverMobile(DriverMobile);
		driver1.setCabNumber(CabNumber);
		driver1.setEmployeeNumber(EmployeeNumber);
		driver1.setPickUpTimer(pickupTime);
		driver1.setCabColorr(CabColor);
		driver1.setCost(EstimatedCost);
		
        //request.setAttribute(BeansForMetroCabs, BeansForMetroCabs);
		
	   

		StatusUpdateService UpdateStatusService= new StatusUpdateService();
	
        try {
		int j = UpdateStatusService.updateStatusDao(booking1,driver1);
		
			 if(j>0){
				 request.setAttribute("mesg", "Update Status.");
				 RequestDispatcher rd=request.getRequestDispatcher("StausOfBookings.jsp");
			     rd.include(request, response); 
		        }
			 else{
				 request.setAttribute("mesg", "Status Updation failed");
			     RequestDispatcher rd=request.getRequestDispatcher("Home.html");
			     rd.include(request, response);   	 
				 
			 }
		}
        catch (ClassNotFoundException | SQLException e)
        {
			e.printStackTrace();
		}
	}


}
