package controllers;
import java.io.*;  
import java.sql.*;  

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;  
import javax.servlet.http.*; 

import connections.ConnectionToDB;

import beans.BeansForMetroCabs;
import dao.BookingDao;
import daoImplementation.BookingDaoImplementation;
import service.BookingService;

public class ServletsForAddingDataToBeansAndDB extends HttpServlet {  
	public int bookingId = 0;
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response)  
			throws ServletException, IOException {  
//Set Response type
		response.setContentType("text/html");  
		PrintWriter out = response.getWriter();  

		String firstName = request.getParameter("firstName");  
		String lastName=request.getParameter("lastName");  
		String time= request.getParameter("time");  
		String city =request.getParameter("city");
		String date=request.getParameter("date");
		String pickupPlace=request.getParameter("pickupPlace");
		String landMark=request.getParameter("landMark");
		String destination=request.getParameter("destination");
		String vehicleType=request.getParameter("vehicleType");
		String serviceType=request.getParameter("serviceType");
		String emailId=request.getParameter("emailId");
		String numberOfPersons=request.getParameter("numberOfPersons");
		String idCardNumber=request.getParameter("idCardNumber");
		String contactNumber=request.getParameter("contactNumber");
		String bookingId=request.getParameter("bookingId");
		System.out.println(bookingId);
		//Setting Values in Beans
		BeansForMetroCabs booking1=new BeansForMetroCabs(); 
		
		
		booking1.setFirstName(firstName);
		booking1.setLastName(lastName);
		booking1.setBookingId(bookingId);
		booking1.setCity(city);
		booking1.setContactNumber(contactNumber);
		booking1.setDate(date);
		booking1.setDestination(destination);
		booking1.setEmail(emailId);
		booking1.setIdCardNumber(idCardNumber);
		booking1.setLandMark(landMark);
		booking1.setNumberOfPersons(numberOfPersons);
		booking1.setPickupPlace(pickupPlace);
		booking1.setServiceType(serviceType);
		booking1.setTypeOfVehicle(vehicleType);
		booking1.settimeOfBooking(time);
		
		
		
		
        //request.setAttribute(BeansForMetroCabs, BeansForMetroCabs);
		
//JDBC Connection and updation
		BookingService bookService=new BookingService();
        try {
        	
		int j = bookService.bookServiceFx(booking1);
		
			 if(j>0){
				 
				request.setAttribute("mesg", booking1);
				
				Connection con=ConnectionToDB.getConnection();
			    Statement st=con.createStatement();
				RequestDispatcher rd=request.getRequestDispatcher("BookingSuccessful.html");
				String x=request.getParameter("contactNumber");
				ResultSet rs= st.executeQuery("Select bookingId from MetroCabs where contactnumber='"+x+"'");
				out.println("<body><fieldset style='border-radius: 5px; padding: 5px; min-height:300px'>");
				while(rs.next())
				{
				out.println("<b>Booking id:<b>"+rs.getString("BookingId"));
			   
				}
				 rd.include(request, response); 
		        }
			 else{
				 request.setAttribute("mesg", "Booking failed");
			     RequestDispatcher rd=request.getRequestDispatcher("Home.html");
			     rd.include(request, response);   	 
				 
			 }
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
        

	}
	
}
		
		

	    
		
	
		
	
	



