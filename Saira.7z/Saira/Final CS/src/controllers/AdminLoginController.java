package controllers;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.PrintWriter;

import org.apache.jasper.tagplugins.jstl.core.Out;

import service.AdminLoginService;

import beans.AdminLogin;


public class AdminLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

		
	

		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				String userName = request.getParameter("userName");
	        	String password = request.getParameter("password");

	        
	        //System.out.println(userName);

	        AdminLogin loginInfo = new AdminLogin( );

	        loginInfo.setUserName(userName);
	        loginInfo.setPassWord(password);

	        AdminLoginService adminloginService = new AdminLoginService( );

	         
	        try{
	        	String i = adminloginService.validateUser(loginInfo);

	        	if(i=="match"){
	        		
		            RequestDispatcher rd = request.getRequestDispatcher("/adminGenerateBookingId1.jsp");
		            rd.forward(request, response);
	        	
	        		        	}
	        	else{
	        		
	        		PrintWriter out = response.getWriter();  
	        		out.println("no match");
	        		RequestDispatcher rd = request.getRequestDispatcher("/adminLogin.jsp");
		            rd.include(request, response);	
	        	}
	        		
	           }

	        catch(ClassNotFoundException ce){
	            ce.printStackTrace();
	           
	        }
	        catch(SQLException se){
	            se.printStackTrace( );
	            
	        }
	       
	       }
	    }
	

